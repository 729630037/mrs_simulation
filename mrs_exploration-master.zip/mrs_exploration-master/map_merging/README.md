# map_merging #

[http://wiki.ros.org/map_merging](http://wiki.ros.org/map_merging)
