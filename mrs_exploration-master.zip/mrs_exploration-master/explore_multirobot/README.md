# explore_multirobot #

[http://wiki.ros.org/explore_multirobot](http://wiki.ros.org/explore_multirobot)
