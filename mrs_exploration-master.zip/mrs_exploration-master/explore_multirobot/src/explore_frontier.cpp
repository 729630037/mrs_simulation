/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2008, Robert Bosch LLC.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of the Robert Bosch nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 *********************************************************************/

/*
 *  Created on: Apr 6, 2009
 *      Author: duhadway
 */

#include <explore/explore_frontier.h>

using namespace visualization_msgs;
using namespace costmap_2d;

namespace explore
{

ExploreFrontier::ExploreFrontier() : map_(),
                                     lastMarkerCount_(0),
                                     planner_(NULL),
                                     frontiers_()
{
}

ExploreFrontier::~ExploreFrontier()
{

}

bool ExploreFrontier::getFrontiers(Costmap2DROS &costmap, std::vector<geometry_msgs::Pose> &frontiers, double inscribed_scale)
{
  findFrontiers(costmap, inscribed_scale);
  if (frontiers_.size() == 0)
    return false;

  frontiers.clear();
  for (uint i = 0; i < frontiers_.size(); i++)
  {
    geometry_msgs::Pose frontier;
    frontiers.push_back(frontiers_[i].pose);
  }

  return (frontiers.size() > 0);
}

float ExploreFrontier::getFrontierCost(const Frontier &frontier)
{
  ROS_DEBUG("cost of frontier: %f, at position: (%.2f, %.2f, %.2f)", planner_->getPointPotential(frontier.pose.position),
            frontier.pose.position.x, frontier.pose.position.y, tf::getYaw(frontier.pose.orientation));
  if (planner_ != NULL)
    return planner_->getPointPotential(frontier.pose.position); // / 20000.0;
  else
    return 1.0;
}

// TODO: what is this doing exactly?
double ExploreFrontier::getOrientationChange(const Frontier &frontier, const geometry_msgs::PoseStamped &robot_pose)
{
  double robot_yaw = tf::getYaw(robot_pose.pose.orientation);
  double robot_atan2 = atan2(robot_pose.pose.position.y + sin(robot_yaw), robot_pose.pose.position.x + cos(robot_yaw));
  double frontier_atan2 = atan2(frontier.pose.position.x, frontier.pose.position.y);
  double orientation_change = robot_atan2 - frontier_atan2;
  //  ROS_DEBUG("Orientation change: %.3f degrees, (%.3f radians)", orientation_change * (180.0 / M_PI), orientation_change);
  return orientation_change;
}

float ExploreFrontier::getFrontierGain(const Frontier &frontier, double map_resolution)
{
  return frontier.size * map_resolution;
}

bool ExploreFrontier::getExplorationGoals(Costmap2DROS &costmap, geometry_msgs::PoseStamped robot_pose, navfn::NavfnROS *planner, std::vector<geometry_msgs::Pose> &goals, double potential_scale, double orientation_scale, double gain_scale, double inscribed_scale)
{
  findFrontiers(costmap, inscribed_scale);
  if (frontiers_.size() == 0)
  {
    return false;
  }

  geometry_msgs::Point start;
  start.x = robot_pose.pose.position.x;
  start.y = robot_pose.pose.position.y;
  start.z = robot_pose.pose.position.z; //own position

  //Compute the full navigation function for the map given the start (current) point of the robot
  planner->computePotential(start); //in getFrontierCost this planner is used to calculate cost from start

  planner_ = planner;
  costmapResolution_ = costmap.getCostmap()->getResolution(); //resolution in meters per cell

  //we'll make sure that we set goals for the frontier at least the circumscribed
  //radius away from unknown space
  float step = -1.0 * costmapResolution_;
  // circumscribed radius is derive from robot footprint (its corners) -> if an obstacle is
  // in that radius there might be a collision (with a corner), but there doesn't have to be one
  int c = ceil(costmap.getLayeredCostmap()->getCircumscribedRadius() / costmapResolution_);
  // e.g.: 0.5m / 0.05 m/cell = 10 cell -> getting the amount of cells the circumscribed radius takes
  WeightedFrontier goal;
  std::vector<WeightedFrontier> weightedFrontiers;
  // increase the size of the weightedFrontier vector by the (circumscribed radius/costmap resolution)-relation
  weightedFrontiers.reserve(frontiers_.size() * c);
  for (uint i = 0; i < frontiers_.size(); i++)
  {
    Frontier &frontier = frontiers_[i];
    WeightedFrontier weightedFrontier;
    weightedFrontier.frontier = frontier;

    tf::Point p(frontier.pose.position.x, frontier.pose.position.y, frontier.pose.position.z);
    tf::Quaternion bt;
    tf::quaternionMsgToTF(frontier.pose.orientation, bt);       //convert quaternion message to quaternion
    tf::Vector3 v(cos(bt.getAngle()), sin(bt.getAngle()), 0.0); //derive 2d direction vector (x,y)

    for (int j = 0; j <= c; j++)
    {                                                 // c is the circumscribed radius (measured in cells)
                                                      //p is the point where current frontier is
                                                      // v direction vector, step (negated) costmap resolution
      tf::Vector3 check_point = p + (v * (step * j)); // calculate new frontier point
      weightedFrontier.frontier.pose.position.x = check_point.x();
      weightedFrontier.frontier.pose.position.y = check_point.y();
      weightedFrontier.frontier.pose.position.z = check_point.z();

      // calculate costs of reaching it: (weighted) cost of reaching point (according to planner) + (weighted) cost for changing the orientation - the (weighted) information gain of frontier (its size in relation to the costmap resolution)
      weightedFrontier.cost = potential_scale * getFrontierCost(weightedFrontier.frontier) + orientation_scale * getOrientationChange(weightedFrontier.frontier, robot_pose) - gain_scale * getFrontierGain(weightedFrontier.frontier, costmapResolution_);
      //      weightedFrontier.cost = getFrontierCost(weightedFrontier.frontier) - getFrontierGain(weightedFrontier.frontier, costmapResolution_);
      //      ROS_DEBUG("cost: %f (%f * %f + %f * %f - %f * %f)",
      //          weightedFrontier.cost,
      //          potential_scale,
      //          getFrontierCost(weightedFrontier.frontier),
      //          orientation_scale,
      //          getOrientationChange(weightedFrontier.frontier, robot_pose),
      //          gain_scale,
      //          getFrontierGain(weightedFrontier.frontier, costmapResolution_) );
      weightedFrontiers.push_back(weightedFrontier);
    }
  }

  goals.clear(); //empty current goals
  goals.reserve(weightedFrontiers.size());
  std::sort(weightedFrontiers.begin(), weightedFrontiers.end());
  for (uint i = 0; i < weightedFrontiers.size(); i++)
  {
    goals.push_back(weightedFrontiers[i].frontier.pose); //adds sorted goals - (lowest cost goals first)
  }
  return (goals.size() > 0);
}

void ExploreFrontier::findFrontiers(Costmap2DROS &costmap_, double inscribed_scale)
{
  frontiers_.clear();

  Costmap2D costmap;
  costmap = *(costmap_.getCostmap());

  int idx;
  int w = costmap.getSizeInCellsX(); // X size of costmap in cells (width)
  int h = costmap.getSizeInCellsY();
  int size = (w * h);

  map_.info.width = w;
  map_.info.height = h;
  map_.data.resize((size_t)size);
  map_.info.resolution = costmap.getResolution();
  map_.info.origin.position.x = costmap.getOriginX();
  map_.info.origin.position.y = costmap.getOriginY();

  // Find all frontiers (open cells next to unknown cells).
  const unsigned char *map = costmap.getCharMap();

  for (idx = 0; idx < size; idx++)
  {
    // //get the world point for the index
    // unsigned int mx, my;
    // costmap.indexToCells(idx, mx, my);
    // geometry_msgs::Point p;
    // costmap.mapToWorld(mx, my, p.x, p.y);
    // //check if the point has valid potential and is next to unknown space
    // bool valid_point = planner_->validPointPotential(p);

    bool valid_point = (map[idx] < LETHAL_OBSTACLE);

    if ((valid_point && map) &&                                    //check if point is not an obstacle and map is not 0
        (((idx + 1 < size) && (map[idx + 1] == NO_INFORMATION)) || //right cell is unknown
         ((idx - 1 >= 0) && (map[idx - 1] == NO_INFORMATION)) ||   //left cell is unknown
         ((idx + w < size) && (map[idx + w] == NO_INFORMATION)) || //top cell is unknown
         ((idx - w >= 0) && (map[idx - w] == NO_INFORMATION))))    //bottom cell is unknown
    {
      map_.data[idx] = -128; // set value if point is at border of an unknown cell
    }
    else
    {
      map_.data[idx] = -127;
    }
  }

  // Clean up frontiers detected on separate rows of the map
  idx = map_.info.height - 1;
  for (unsigned int y = 0; y < map_.info.width; y++)
  { //OccupancyGrid is row-major order
    map_.data[idx] = -127;
    idx += map_.info.height;
  }

  // Group adjoining map_ pixels
  int segment_id = 127;
  std::vector<std::vector<FrontierPoint>> segments;
  for (int i = 0; i < size; i++)
  {
    if (map_.data[i] == -128)
    {
      std::vector<int> neighbors;
      std::vector<FrontierPoint> segment;
      neighbors.push_back(i);

      // claim all neighbors
      while (neighbors.size() > 0)
      {
        int idx = neighbors.back();
        neighbors.pop_back();
        map_.data[idx] = segment_id; //setting it to another value than -128, creating connected segment fields
                                    //if there were just one cluster, the outer loop would be executed just once
                                    // but previous "clean up" prevents this 
        btVector3 tot(0, 0, 0);
        int c = 0;
        if ((idx + 1 < size) && (map[idx + 1] == NO_INFORMATION)) //right cell is unknown
        {
          tot += btVector3(1, 0, 0);
          c++;
        }
        if ((idx - 1 >= 0) && (map[idx - 1] == NO_INFORMATION)) //left cell is unknown
        {
          tot += btVector3(-1, 0, 0);
          c++;
        }
        if ((idx + w < size) && (map[idx + w] == NO_INFORMATION)) //upper cell is unknown
        {
          tot += btVector3(0, 1, 0);
          c++;
        }
        if ((idx - w >= 0) && (map[idx - w] == NO_INFORMATION)) //lower cell is unknown
        {
          tot += btVector3(0, -1, 0);
          c++;
        }
        assert(c > 0);
        segment.push_back(FrontierPoint(idx, tot / c)); //second argument is the vector pointing to the direction of the unknown space

        // consider 8 neighborhood
        if (((idx - 1) > 0) && (map_.data[idx - 1] == -128))
          neighbors.push_back(idx - 1);
        if (((idx + 1) < size) && (map_.data[idx + 1] == -128))
          neighbors.push_back(idx + 1);
        if (((idx - map_.info.width) > 0) && (map_.data[idx - map_.info.width] == -128))
          neighbors.push_back(idx - map_.info.width);
        if (((idx - map_.info.width + 1) > 0) && (map_.data[idx - map_.info.width + 1] == -128))
          neighbors.push_back(idx - map_.info.width + 1);
        if (((idx - map_.info.width - 1) > 0) && (map_.data[idx - map_.info.width - 1] == -128))
          neighbors.push_back(idx - map_.info.width - 1);
        if (((idx + (int)map_.info.width) < size) && (map_.data[idx + map_.info.width] == -128))
          neighbors.push_back(idx + map_.info.width);
        if (((idx + (int)map_.info.width + 1) < size) && (map_.data[idx + map_.info.width + 1] == -128))
          neighbors.push_back(idx + map_.info.width + 1);
        if (((idx + (int)map_.info.width - 1) < size) && (map_.data[idx + map_.info.width - 1] == -128))
          neighbors.push_back(idx + map_.info.width - 1);
      }

      segments.push_back(segment);
      segment_id--;
      if (segment_id < -127)
        break;
    }
  }

  int num_segments = 127 - segment_id;
  if (num_segments <= 0) {
    ROS_INFO("Tried to find find frontiers of unexplored space but none were found.");
    return;
    }

  for (unsigned int i = 0; i < segments.size(); i++)
  {
    Frontier frontier;
    std::vector<FrontierPoint> &segment = segments[i]; // a single segment consists of several frontier points
    uint size = segment.size(); // -> number of frontier points in segment

    //we want to make sure that the frontier is big enough for the robot to fit through
    //std::cout << "InscribedRadius = " << costmap.getInscribedRadius() << std::endl;
    if (size * costmap.getResolution() < costmap_.getLayeredCostmap()->getInscribedRadius() * inscribed_scale)
      continue;

    float x = 0, y = 0;
    btVector3 d(0, 0, 0);

    for (uint j = 0; j < size; j++) //iterate over all frontier points in a segment
    {
      d += segment[j].d; //add up direction vectors of frontier points
      int idx = segment[j].idx;
      x += (idx % map_.info.width); //add up x direction of frontiers, floored
      y += (idx / map_.info.width);  //add up x direction with rest
    }
    d = d / size; //average direction
    frontier.pose.position.x = map_.info.origin.position.x + map_.info.resolution * (x / size); // average x coordinate of frontier points
    frontier.pose.position.y = map_.info.origin.position.y + map_.info.resolution * (y / size); // average y coordinate
    frontier.pose.position.z = 0.0;

    frontier.pose.orientation = tf::createQuaternionMsgFromYaw(btAtan2(d.y(), d.x()));
    frontier.size = size;

    frontiers_.push_back(frontier); //adding frontier for the entire segment
  }
  
}

void ExploreFrontier::getVisualizationMarkers(std::vector<Marker> &markers, std::string tf_prefix)
{
  Marker m;
  m.header.frame_id = tf_prefix + "/map";
  m.header.stamp = ros::Time::now();
  m.id = 0;
  m.ns = "frontiers";
  m.type = Marker::ARROW;
  m.pose.position.x = 0.0;
  m.pose.position.y = 0.0;
  m.pose.position.z = 0.0;
  m.scale.x = 1.0;
  m.scale.y = 1.0;
  m.scale.z = 1.0;
  m.color.r = 0;
  m.color.g = 0;
  m.color.b = 255;
  m.color.a = 255;
  m.lifetime = ros::Duration(0);

  m.action = Marker::ADD;
  uint id = 0;
  for (uint i = 0; i < frontiers_.size(); i++)
  {
    Frontier frontier = frontiers_[i];
    m.id = id;
    m.pose = frontier.pose;
    markers.push_back(Marker(m));
    id++;
  }

  m.action = Marker::DELETE;
  for (; id < lastMarkerCount_; id++)
  {
    m.id = id;
    markers.push_back(Marker(m));
  }

  lastMarkerCount_ = markers.size();
}

} // namespace explore
